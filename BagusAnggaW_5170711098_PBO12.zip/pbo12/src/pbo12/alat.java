
package pbo12;
import java.util.Scanner;
public class alat {
  static String nama;
  static String merk;
  static long harga;
  static Scanner input = new Scanner(System.in);
  
  public void nama(){
      System.out.print("nama = ");
      nama = input.next();
  }
  public void merk(){
      System.out.print("merk = ");
      merk = input.next();
  }
  public void harga(){
      System.out.print("harga = ");
      harga = input.nextLong();
  }
}


package pbo12;

public class alatKesehatan extends alat {
    static String manfaat;
    static String jenis;
    
    public void jenis(){
        System.out.print("jenis = ");
        jenis = input.next();
    }
    public void manfaat(){
        System.out.print("manfaat = ");
        manfaat = input.next();
    }
}

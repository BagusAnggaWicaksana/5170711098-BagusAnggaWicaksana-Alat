
package pbo12;

public class alatMandi extends alat {
    static String warna;
    static String wujud;
    
    public void wujud(){
        System.out.print("wujud = ");
        wujud = input.next();
    }
    public void warna(){
        System.out.print("warna = ");
        warna = input.next();
    }
}

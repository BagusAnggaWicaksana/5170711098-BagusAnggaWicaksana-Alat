
package pbo12;

public class alatTulis extends alat {
    static String fungsi;
    static String ukuran;
    static Double panjang,lebar;
    
    
    public void fungsi(){
        System.out.print("fungsi = ");
        fungsi = input.next();
    }
    public void ukuran(){
        System.out.print("panjang = ");
        panjang = input.nextDouble();
        System.out.print("lebar = ");
        lebar = input.nextDouble();
    }
}


package pbo12;
import java.util.Scanner;
public class Pbo12 {

    public static void main(String[] args) {
        int jumlah,no,ulang;
        Scanner input = new Scanner(System.in);
        alat ada = new alat();
        alatTulis ini = new alatTulis();
        alatMandi situ = new alatMandi();
        alatKesehatan sini = new alatKesehatan();
        do{
         System.out.println(" --- sedia : ---");
         System.out.println("1.Alat Tulis");
         System.out.println("2.Alat Mandi");
         System.out.println("3.Alat Kesehatan");
         System.out.print("jumlah alat :");
         jumlah = input.nextInt();
        
         for (int x = 1; x <= jumlah; x++) {
            System.out.println("\nData Ke-" + x);
            
         System.out.print("masukkan pilihan :");
         no = input.nextInt();
         if(no==1){
             ada.nama();
             ada.merk();
             ada.harga();
             ini.fungsi();
             ini.ukuran();
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Fungsi = " + alatTulis.fungsi);
              System.out.println("Ukuran = " + alatTulis.ukuran);
         }
         else if(no==2){
             ada.nama();
             ada.merk();
             ada.harga();
             situ.wujud();
             situ.warna();
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Wujud = " + alatMandi.wujud);
              System.out.println("Warna = " + alatMandi.warna);
         }
         else if(no==3){
             ada.nama();
             ada.merk();
             ada.harga();
             sini.jenis();
             sini.manfaat();
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Jenis = " + alatKesehatan.jenis);
              System.out.println("Manfaat = " + alatKesehatan.manfaat);
         }
         else{
             System.out.print("barang tidak tersedia");
         }
         System.out.println("");
         System.out.println("----------------------");
         System.out.println("");
       if(no==1){
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Fungsi = " + alatTulis.fungsi);
              System.out.println("Ukuran = " + alatTulis.ukuran);
         }
         else if(no==2){
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Wujud = " + alatMandi.wujud);
              System.out.println("Warna = " + alatMandi.warna);
         }
         else if(no==3){
              System.out.println("Nama = " + alat.nama);
              System.out.println("Merk = " + alat.merk);
              System.out.println("Harga = " + alat.harga);
              System.out.println("Jenis = " + alatKesehatan.jenis);
              System.out.println("Manfaat = " + alatKesehatan.manfaat);
         }
         else{
             System.out.print("barang tidak tersedia");
         }
     }
     System.out.print("belanja lagi ? [Y=1/N=2]");
     ulang = input.nextInt();
    }
     while(ulang == 1);
 } 
}
    
  